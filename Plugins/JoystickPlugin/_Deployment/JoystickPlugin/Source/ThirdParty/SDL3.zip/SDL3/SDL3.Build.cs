// Fill out your copyright notice in the Description page of Project Settings.

using System.IO;
using UnrealBuildTool;

public class SDL3 : ModuleRules
{
	public SDL3(ReadOnlyTargetRules Target) : base(Target)
	{
		Type = ModuleType.External;

        PublicDefinitions.Add("SDL_STATIC=1");
        PublicDefinitions.Add("SDL_SHARED=0");
        PublicDefinitions.Add("EPIC_EXTENSIONS=0");
        PublicDefinitions.Add("SDL_DEPRECATED=1");
        //PublicDefinitions.Add("SDL_WITH_EPIC_EXTENSIONS=1");
        //PublicDefinitions.Add("WIN32");

        string includePath = Path.Combine(ModuleDirectory, "include");
        PublicIncludePaths.AddRange(new string[] { includePath });

        if (Target.Platform == UnrealTargetPlatform.Win64)
		{
			PublicAdditionalLibraries.Add(Path.Combine(ModuleDirectory, "lib", "SDL3.lib"));
			PublicAdditionalLibraries.Add(Path.Combine(ModuleDirectory, "lib", "SDL3-static.lib"));
            PublicDelayLoadDLLs.Add("SDL3.dll");            
        }
        
    }
}
