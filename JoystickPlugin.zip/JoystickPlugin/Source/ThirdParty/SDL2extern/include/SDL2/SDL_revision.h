#define SDL_REVISION "https://github.com/tsky1971/SDL.git@a1e992b110b9adf3305a5ebb5514f0e970f7911e"
#define SDL_REVISION_NUMBER 0

#ifndef SDL_REVISION
#define SDL_REVISION ""
#endif
